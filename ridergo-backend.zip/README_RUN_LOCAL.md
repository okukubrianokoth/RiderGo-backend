# RiderGo Backend - Run Locally

## Requirements:
- Node.js 18+
- MongoDB Atlas account

## Steps
unzip ridergo-backend.zip
cd backend
cp .env.example .env
nano .env   # add Gmail app password
npm install
npm start

API will run at http://localhost:5000
